package unidade1;

import javax.swing.JOptionPane;

public class AloMundo {

	public static void main(String[] args) {
		System.out.println("Alo Mundo!");
		JOptionPane.showMessageDialog(null, "Alo Mundo!");

	}

}
