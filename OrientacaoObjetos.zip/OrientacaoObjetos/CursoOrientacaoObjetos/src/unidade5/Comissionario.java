package unidade5;

public final class Comissionario extends ServidorPublico {

}
