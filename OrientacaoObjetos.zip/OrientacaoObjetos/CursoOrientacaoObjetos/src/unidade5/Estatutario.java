package unidade5;

public final class Estatutario extends ServidorPublico {

}
