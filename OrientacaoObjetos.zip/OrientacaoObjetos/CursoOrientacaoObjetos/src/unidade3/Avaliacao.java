package unidade3;

public enum Avaliacao {
	
	EXCELENTE,
	BOM,
	REGULAR,
	INSATISFATORIO

}
