package unidade4;

/*********************************/
public class Temporario 
			extends ServidorPublico
/*********************************/
			
{

	private static final int VALOR_HORA_EXTRA = 30;
	private String contrato;
	private double salario;
	
	//Construtor
	public Temporario(String contrato, double salario, int matricula, String nome) {
		super(matricula, nome);
		this.contrato = contrato;
		this.salario = salario;
	}
	
	//Métodos Getters e Setters
	public String getContrato() {
		return contrato;
	}
	public void setContrato(String contrato) {
		this.contrato = contrato;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}

	@Override
	public String toString() {
		return "Temporario [contrato=" + contrato + ", salario=" + salario + ", matricula=" + matricula + ", nome="
				+ nome + "]";
	}
	
	public final double calcularSalarioHorasExtras(int horasTrabalhadas)
	{
		/***** Variável Local dentro do método de propriedade*****/
		double salarioMensal = 0;
		
		salarioMensal = salarioMensal + horasTrabalhadas * VALOR_HORA_EXTRA;
		
		return (this.salario + salarioMensal);
	}
	
}
