package unidade4;

/***********************/
public class Estatutario 
			extends ServidorPublico
/***********************/
{

	private int tempoServico;
	private double salarioBase;
	
	
	//Construtor
	public Estatutario(int tempoServico, double salarioBase, int matricula, String nome) {
		super(matricula, nome);
		this.tempoServico = tempoServico;
		this.salarioBase = salarioBase;
	}

	//Métodos Getters e Setters
	public int getTempoServico() {
		return tempoServico;
	}


	public void setTempoServico(int tempoServico) {
		this.tempoServico = tempoServico;
	}


	public double getSalarioBase() {
		return salarioBase;
	}


	public void setSalarioBase(double salarioBase) {
		this.salarioBase = salarioBase;
	}

	//To String
	@Override
	public String toString() {
		return "Estatutario [Matricula ="+matricula+" - Nome = "+nome+" - tempoServico=" + tempoServico + ", - salarioBase=" + salarioBase + "]";
	}
	
	
	
	
}
