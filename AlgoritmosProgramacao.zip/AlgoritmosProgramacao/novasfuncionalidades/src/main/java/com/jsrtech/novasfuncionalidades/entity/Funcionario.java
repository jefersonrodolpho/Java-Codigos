package com.jsrtech.novasfuncionalidades.entity;

import java.util.Objects;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="funcionarios")
public class Funcionario {

	private int id;
    private String nome;
    private String sobrenome;
    private String email;
    private String genero;
    private String cidade;
    private String pais;
    private String empresa;
    private double salario;
    
    
    
	public Funcionario(int id, String nome, String sobrenome, String email, String genero, String cidade, String pais,
			String empresa, double salario) {
		super();
		this.id = id;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.email = email;
		this.genero = genero;
		this.cidade = cidade;
		this.pais = pais;
		this.empresa = empresa;
		this.salario = salario;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getEmpresa() {
		return empresa;
	}
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	@Override
	public int hashCode() {
		return Objects.hash(cidade, email, empresa, genero, id, nome, pais, salario, sobrenome);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcionario other = (Funcionario) obj;
		return Objects.equals(cidade, other.cidade) && Objects.equals(email, other.email)
				&& Objects.equals(empresa, other.empresa) && Objects.equals(genero, other.genero) && id == other.id
				&& Objects.equals(nome, other.nome) && Objects.equals(pais, other.pais)
				&& Double.doubleToLongBits(salario) == Double.doubleToLongBits(other.salario)
				&& Objects.equals(sobrenome, other.sobrenome);
	}
	@Override
	public String toString() {
		return "Funcionario [id=" + id + ", nome=" + nome + ", sobrenome=" + sobrenome + ", email=" + email
				+ ", genero=" + genero + ", cidade=" + cidade + ", pais=" + pais + ", empresa=" + empresa + ", salario="
				+ salario + "]";
	}
	
    
    
}
