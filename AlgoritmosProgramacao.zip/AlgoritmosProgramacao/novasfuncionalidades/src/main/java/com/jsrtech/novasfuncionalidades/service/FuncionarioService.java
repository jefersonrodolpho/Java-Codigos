package com.jsrtech.novasfuncionalidades.service;

import java.util.List;

import com.jsrtech.novasfuncionalidades.entity.Funcionario;

public interface FuncionarioService {

	List<Funcionario> listAll();
	
}
