package unidade4;

import java.util.Scanner;

public class Fatorialv2 {

	public static void main(String[] args) {


		double fatorial = 1;
		int numero, i;
		
		Scanner teclado = new Scanner(System.in);
        System.out.println("Favor informar o numero");
        numero = teclado.nextInt();
        i = numero;
        
		do // utilizando a estrutura de repetição
		{
			fatorial = fatorial * i;
			i --; //numero = numero -1;
		}
		while(i >= 1);
		
	    System.out.println("O Fatorial do numero:"+numero+"="+fatorial);
    
	    teclado.close();
	}

}
