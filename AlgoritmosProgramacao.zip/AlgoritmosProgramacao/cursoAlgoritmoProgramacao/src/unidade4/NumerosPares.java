package unidade4;

import java.util.Scanner;

public class NumerosPares {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
        System.out.println("Favor informar o número A");
        var a = teclado.nextInt();

        System.out.println("Favor informar o número B");
        var b = teclado.nextInt();
        
        for(int i=a;i<=b;i++) //para excluir os números de A e B faça o seguinte: for(int i=a+1;i<b;i++)
        {
        	if (i%2==0) //é par?
        		System.out.println("O número:"+i+" é par!");
        }
        teclado.close();
	}

}
