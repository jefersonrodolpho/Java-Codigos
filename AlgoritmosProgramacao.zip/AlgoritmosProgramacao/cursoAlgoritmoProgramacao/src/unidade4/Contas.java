package unidade4;

import javax.swing.JOptionPane;

public class Contas {

	public static void main(String[] args) {
		
		
		var descricao_conta = JOptionPane.showInputDialog("Digite o Nome da Conta");
		var valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o seu valor"));
		int numero_contas = 0;
		double valor_total = 0;
		
		while(valor>0)
		{
			JOptionPane.showMessageDialog(null,"Conta:"+descricao_conta+" - Valor"+valor);
			numero_contas++;
			valor_total = valor_total + valor;
			descricao_conta = JOptionPane.showInputDialog("Digite o Nome da Conta");
			valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o seu valor"));
			
		}
		JOptionPane.showMessageDialog(null,"Número de conta(s):"+numero_contas+" - Valor:R$"+valor_total);
	}

}
//para finalizar a somatória das contas tem que inserir o valor 0