package unidade5;

public class MatrizIdentidade {

	public static void main(String[] args) {


		int i,j;
		int matrizI[][] = new int [3][3];
		
		for(i=0;i<3;i++)
			for(j=0;j<3;j++)
			{
				if (i == j)
					matrizI[i][j] = 1;
				else
					matrizI[i][j] = 0;
			}
		
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
				System.out.print(matrizI[i][j]);
		System.out.println();	
			}

	}

}
